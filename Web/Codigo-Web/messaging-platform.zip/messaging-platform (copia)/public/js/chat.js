let socket;
let currentChat = null;
let currentChatType = null; // 'private' o 'group'
let currentUserId = null;
let isSending = false; // Control para evitar envíos múltiples

// Inicializar WebSocket
function initWebSocket(userId) {
  currentUserId = userId;
  socket = new WebSocket(`ws://${window.location.hostname}:${window.location.port}`);

  socket.onopen = () => {
    console.log('WebSocket connected');
    socket.send(JSON.stringify({ 
      type: 'register', 
      userId: currentUserId 
    }));
    loadUserGroups();
  };

  socket.onmessage = async (event) => {
    const data = JSON.parse(event.data);
    console.log('WebSocket message:', data.type);
    
    switch (data.type) {
      case 'message':
        if (data.chatType === 'private' && 
            ((data.senderId === currentChat && currentChatType === 'private') || 
             (data.recipientId === currentChat && currentChatType === 'private'))) {
          let displayContent = data.content;
          
          if (data.isEncrypted) {
            try {
              displayContent = await decryptMessage(data.content);
            } catch (err) {
              console.error('Error decrypting message:', err);
              displayContent = "🔒 No se pudo descifrar este mensaje";
            }
          }
          
          displayMessage({
            senderId: data.senderId,
            senderUsername: data.senderUsername,
            content: displayContent,
            timestamp: data.timestamp,
            isCurrentUser: data.senderId === currentUserId
          });
          scrollToBottom();
        }
        break;
        
      case 'group-message':
        if (data.channelId === currentChat && currentChatType === 'group') {
          displayMessage({
            _id: data._id,
            senderId: data.senderId,
            senderUsername: data.senderUsername,
            content: data.content,
            timestamp: data.timestamp,
            isCurrentUser: data.senderId === currentUserId
          });
          scrollToBottom();
        }
        break;
        
      case 'user-status':
        updateUserStatus(data.userId, data.status);
        break;
        
      case 'call-offer':
        handleIncomingCall(data);
        break;
        
      case 'error':
        if (data.originalType === 'group-message') {
          alert(`Error: ${data.message}`);
        }
        break;
    }
  };

  socket.onclose = () => {
    console.log('WebSocket disconnected. Reconnecting...');
    setTimeout(() => initWebSocket(userId), 5000);
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
}

// Función para cifrar mensajes
async function encryptMessage(content, recipientPublicKey) {
  try {
    const key = await window.crypto.subtle.importKey(
      "jwk",
      recipientPublicKey,
      { name: "RSA-OAEP", hash: "SHA-256" },
      true,
      ["encrypt"]
    );

    const encoded = new TextEncoder().encode(content);
    const encrypted = await window.crypto.subtle.encrypt(
      { name: "RSA-OAEP" },
      key,
      encoded
    );

    return btoa(String.fromCharCode(...new Uint8Array(encrypted)));
  } catch (error) {
    console.error("Error en encryptMessage:", error);
    throw error;
  }
}

// Función para descifrar mensajes
async function decryptMessage(encryptedContent) {
  try {
    const privateKey = JSON.parse(localStorage.getItem(`e2ee_${currentUserId}_private`));
    if (!privateKey) throw new Error("No private key found");

    const key = await window.crypto.subtle.importKey(
      "jwk",
      privateKey,
      { name: "RSA-OAEP", hash: "SHA-256" },
      true,
      ["decrypt"]
    );

    const encryptedArray = Uint8Array.from(atob(encryptedContent), c => c.charCodeAt(0));
    const decrypted = await window.crypto.subtle.decrypt(
      { name: "RSA-OAEP" },
      key,
      encryptedArray
    );

    return new TextDecoder().decode(decrypted);
  } catch (error) {
    console.error("Error en decryptMessage:", error);
    return "🔒 Mensaje cifrado (no se pudo descifrar)";
  }
}

// Configurar input de mensajes
function setupMessageInput() {
  const messageInput = document.getElementById('message-input');
  const sendMessageBtn = document.getElementById('send-message-btn');
  
  messageInput.disabled = false;
  sendMessageBtn.disabled = false;

  const sendMessage = async () => {
    if (isSending) return;
    isSending = true;
    
    const content = messageInput.value.trim();
    if (!content || !currentChat) {
      isSending = false;
      return;
    }

    try {
      const timestamp = new Date().toISOString();

      if (currentChatType === 'private') {
        // Lógica para mensajes privados con cifrado
        let encryptedContent = content;
        let isEncrypted = false;

        try {
          const response = await fetch(`/api/e2ee/keys/${currentChat}`, {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          
          if (response.ok) {
            const { publicKey } = await response.json();
            if (publicKey) {
              encryptedContent = await encryptMessage(content, publicKey);
              isEncrypted = true;
            }
          }
        } catch (error) {
          console.warn("Error en cifrado E2EE:", error);
        }

        socket.send(JSON.stringify({
          type: 'message',
          senderId: currentUserId,
          recipientId: currentChat,
          content: encryptedContent,
          chatType: 'private',
          timestamp: timestamp,
          isEncrypted: isEncrypted
        }));

        // Mostrar mensaje localmente
        displayMessage({
          senderId: currentUserId,
          senderUsername: JSON.parse(localStorage.getItem('user')).username,
          content: content,
          timestamp: timestamp,
          isCurrentUser: true
        });

      } else if (currentChatType === 'group') {
        // Lógica para mensajes grupales (sin cifrado)
        socket.send(JSON.stringify({
          type: 'group-message',
          senderId: currentUserId,
          channelId: currentChat,
          content: content,
          timestamp: timestamp
        }));

        // Mostrar mensaje localmente
        displayMessage({
          senderId: currentUserId,
          senderUsername: JSON.parse(localStorage.getItem('user')).username,
          content: content,
          timestamp: timestamp,
          isCurrentUser: true
        });
      }
      
      messageInput.value = '';
      scrollToBottom();
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Error al enviar el mensaje');
    } finally {
      isSending = false;
    }
  };

  const handleSend = () => {
    sendMessage().catch(err => {
      console.error('Error in send handler:', err);
      isSending = false;
    });
  };

  // Configurar event listeners
  messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSend();
  });

  sendMessageBtn.addEventListener('click', handleSend);
}

// Abrir chat privado
async function openPrivateChat(userId, username) {
  try {
    // Establecer el chat actual
    currentChat = userId;
    currentChatType = 'private';
    
    // Actualizar la UI
    document.getElementById('chat-title').textContent = username;
    document.getElementById('start-call-btn').disabled = false;
    document.getElementById('message-input').disabled = false;
    document.getElementById('send-message-btn').disabled = false;
    
    // Cargar mensajes existentes
    const response = await fetch(`/api/private-chat/${userId}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const messages = await response.json();
    
    // Mostrar mensajes
    displayMessages(messages);
    
    // Configurar el input de mensajes
    setupMessageInput();
    
    // Desplazarse al final del chat
    scrollToBottom();
    
  } catch (error) {
    console.error('Error loading private chat:', error);
    
    // Restablecer el estado del chat
    currentChat = null;
    currentChatType = null;
    document.getElementById('messages-container').innerHTML = 
      '<div class="error-message">Error al cargar el chat</div>';
    document.getElementById('chat-title').textContent = 'Selecciona un chat';
    document.getElementById('message-input').disabled = true;
    document.getElementById('send-message-btn').disabled = true;
    
    alert('Error al cargar el chat. Por favor, intenta nuevamente.');
  }
}

// Abrir chat de grupo
async function openGroupChat(groupId, groupName) {
  currentChat = groupId;
  currentChatType = 'group';
  document.getElementById('chat-title').textContent = groupName;
  document.getElementById('start-call-btn').disabled = true;
  
  try {
    // Unirse al grupo en WebSocket
    socket.send(JSON.stringify({
      type: 'join-group',
      channelId: groupId,
      userId: currentUserId
    }));
    
    // Cargar mensajes existentes
    const response = await fetch(`/api/channels/${groupId}/messages`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading messages');
    
    const messages = await response.json();
    displayMessages(messages);
    setupMessageInput();
  } catch (error) {
    console.error('Error loading group chat:', error);
    alert('Error al cargar el grupo');
  }
}

// Mostrar mensajes
function displayMessages(messages) {
  const messagesContainer = document.getElementById('messages-container');
  messagesContainer.innerHTML = '';
  
  if (messages.length === 0) {
    messagesContainer.innerHTML = '<div class="no-messages">No hay mensajes aún</div>';
    return;
  }
  
  messages.forEach(message => {
    displayMessage(message);
  });
  
  scrollToBottom();
}

// Mostrar un mensaje individual
function displayMessage(message) {
  const messagesContainer = document.getElementById('messages-container');
  const isCurrentUser = message.isCurrentUser;
  
  const messageElement = document.createElement('div');
  messageElement.className = `message ${isCurrentUser ? 'my-message' : 'contact-message'}`;
  
  const messageTime = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
  
  messageElement.innerHTML = `
    <div class="message-sender">${isCurrentUser ? 'Tú' : message.senderUsername}</div>
    <div class="message-content">${message.content}</div>
    <div class="message-time">${messageTime}</div>
  `;
  
  messagesContainer.appendChild(messageElement);
}

// Función para desplazarse al final del chat
function scrollToBottom() {
  const messagesContainer = document.getElementById('messages-container');
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Actualizar estado de usuario
function updateUserStatus(userId, status) {
  const contacts = document.querySelectorAll('.contact-item');
  contacts.forEach(contact => {
    if (contact.dataset.userid === userId) {
      const statusIndicator = contact.querySelector('.contact-status');
      statusIndicator.className = `contact-status ${status === 'online' ? 'status-online' : 'status-offline'}`;
    }
  });
}

// Cargar contactos
async function loadContacts() {
  try {
    const response = await fetch('/api/contacts', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error al cargar contactos');
    
    const contacts = await response.json();
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = '';
    
    if (contacts.length === 0) {
      contactsList.innerHTML = '<div class="no-contacts">No tienes contactos aún</div>';
      return;
    }
    
    // Dentro de la función loadContacts, en el forEach de contacts:
    contacts.forEach(contact => {
      const contactItem = document.createElement('div');
      contactItem.className = 'contact-item';
      contactItem.dataset.userid = contact._id;
      contactItem.innerHTML = `
        <div class="contact-status ${contact.status === 'online' ? 'status-online' : 'status-offline'}"></div>
        <span>${contact.username}</span>
        <div class="contact-actions">
          <button class="remove-friend-btn" data-userid="${contact._id}">Eliminar</button>
        </div>
      `;
      
      // Evento para abrir el chat al hacer clic en el contacto
      contactItem.addEventListener('click', (e) => {
        // Solo abrir chat si no se hizo clic en el botón de eliminar
        if (!e.target.classList.contains('remove-friend-btn')) {
          openPrivateChat(contact._id, contact.username);
        }
      });
      
      // Evento para el botón de eliminar
      const removeBtn = contactItem.querySelector('.remove-friend-btn');
      removeBtn.addEventListener('click', async (e) => {
        e.stopPropagation(); // Evitar que el evento de clic del contacto se dispare
        await removeFriend(contact._id);
      });
      
      contactsList.appendChild(contactItem);
    });
  } catch (error) {
    console.error('Error loading contacts:', error);
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = `
      <div class="error-message">
        Error al cargar contactos. <button onclick="loadContacts()">Reintentar</button>
      </div>
    `;
  }
}

// Cargar grupos del usuario
async function loadUserGroups() {
  try {
    const response = await fetch('/api/user/channels', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading groups');
    
    const groups = await response.json();
    const groupsList = document.getElementById('groups-list');
    groupsList.innerHTML = '';
    
    if (groups.length === 0) {
      groupsList.innerHTML = '<div class="no-groups">No estás en ningún grupo</div>';
      return;
    }
    
    groups.forEach(group => {
      const groupElement = document.createElement('div');
      groupElement.className = 'group-item';
      groupElement.dataset.groupid = group._id;
      groupElement.innerHTML = `
        <div class="group-info">
          <div class="group-name">${group.name}</div>
          <div class="group-description">${group.description || 'Sin descripción'}</div>
          <div class="group-members">${group.members.length} miembros</div>
        </div>
        <div class="group-actions">
          <button class="leave-group-btn" data-groupid="${group._id}">Salir</button>
          ${group.created_by._id === JSON.parse(localStorage.getItem('user')).id ? 
            `<button class="delete-group-btn" data-groupid="${group._id}">Eliminar</button>` : ''}
        </div>
      `;
      
      groupElement.addEventListener('click', () => {
        openGroupChat(group._id, group.name);
      });
      
      const leaveBtn = groupElement.querySelector('.leave-group-btn');
      leaveBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await leaveGroup(group._id);
      });
      
      const deleteBtn = groupElement.querySelector('.delete-group-btn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (confirm('¿Estás seguro de eliminar este grupo?')) {
            await deleteGroup(group._id);
          }
        });
      }
      
      groupsList.appendChild(groupElement);
    });
  } catch (error) {
    console.error('Error loading user groups:', error);
  }
}

// Funciones para manejar grupos
async function leaveGroup(groupId) {
  try {
    const response = await fetch(`/api/channels/${groupId}/leave`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      alert(data.message);
      loadUserGroups();
      
      // Salir del grupo en WebSocket
      socket.send(JSON.stringify({
        type: 'leave-group',
        channelId: groupId,
        userId: currentUserId
      }));
      
      // Si estábamos en ese grupo, cerrar el chat
      if (currentChat === groupId) {
        currentChat = null;
        currentChatType = null;
        document.getElementById('messages-container').innerHTML = '<div>Selecciona un chat</div>';
        document.getElementById('chat-title').textContent = 'Selecciona un chat';
        document.getElementById('message-input').disabled = true;
        document.getElementById('send-message-btn').disabled = true;
      }
    } else {
      alert(data.message || 'Error al salir del grupo');
    }
  } catch (error) {
    console.error('Error leaving group:', error);
    alert('Error al conectar con el servidor');
  }
}

async function deleteGroup(groupId) {
  try {
    const response = await fetch(`/api/channels/${groupId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      alert(data.message);
      loadUserGroups();
      
      // Si estábamos en ese grupo, cerrar el chat
      if (currentChat === groupId) {
        currentChat = null;
        currentChatType = null;
        document.getElementById('messages-container').innerHTML = '<div>Selecciona un chat</div>';
        document.getElementById('chat-title').textContent = 'Selecciona un chat';
        document.getElementById('message-input').disabled = true;
        document.getElementById('send-message-btn').disabled = true;
      }
    } else {
      alert(data.message || 'Error al eliminar el grupo');
    }
  } catch (error) {
    console.error('Error deleting group:', error);
    alert('Error al conectar con el servidor');
  }
}

// Inicializar llamada
document.getElementById('start-call-btn').addEventListener('click', () => {
  if (currentChatType === 'private' && currentChat) {
    startCall(currentChat);
  }
});

// Finalizar llamada
document.getElementById('end-call-btn').addEventListener('click', endCall);

// Configurar el buscador de usuarios
function setupUserSearch() {
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  
  searchInput.addEventListener('input', handleUserSearch);
  
  // Cerrar resultados al hacer clic fuera
  document.addEventListener('click', (e) => {
    if (!searchResults.contains(e.target)) {
      searchResults.classList.add('hidden');
    }
  });
}

// Manejar la búsqueda de usuarios
async function handleUserSearch(e) {
  const query = e.target.value.trim();
  const searchResults = document.getElementById('search-results');
  
  if (query.length < 2) {
    searchResults.classList.add('hidden');
    return;
  }

  try {
    const response = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error en la búsqueda');
    
    const users = await response.json();
    displaySearchResults(users);
  } catch (error) {
    console.error('Error searching users:', error);
    searchResults.innerHTML = '<div class="search-result-item error">Error al buscar usuarios</div>';
    searchResults.classList.remove('hidden');
  }
}

// Mostrar resultados de búsqueda
function displaySearchResults(users) {
  const searchResults = document.getElementById('search-results');
  const currentUser = JSON.parse(localStorage.getItem('user'));
  const currentFriends = Array.from(document.querySelectorAll('.contact-item'))
    .map(el => el.dataset.userid);
  
  searchResults.innerHTML = '';
  
  if (users.length === 0) {
    searchResults.innerHTML = '<div class="search-result-item">No se encontraron usuarios</div>';
  } else {
    users.forEach(user => {
      const isAlreadyFriend = currentFriends.includes(user._id);
      
      const userElement = document.createElement('div');
      userElement.className = 'search-result-item';
      userElement.innerHTML = `
        <div class="user-info">
          <div class="username">${user.username}</div>
          <div class="user-status ${user.status === 'online' ? 'online' : ''}">
            ${user.status === 'online' ? 'En línea' : 'Desconectado'}
          </div>
        </div>
        <button class="add-friend-btn" 
                data-userid="${user._id}" 
                ${isAlreadyFriend ? 'disabled' : ''}>
          ${isAlreadyFriend ? 'Ya es contacto' : 'Añadir'}
        </button>
      `;
      
      if (!isAlreadyFriend) {
        userElement.querySelector('.add-friend-btn').addEventListener('click', async () => {
          await addFriend(user._id);
        });
      }
      
      searchResults.appendChild(userElement);
    });
  }
  
  searchResults.classList.remove('hidden');
}

// Añadir un nuevo contacto
async function addFriend(userId) {
  try {
    const response = await fetch(`/api/friends/${userId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) throw new Error('Error al añadir amigo');
    
    const data = await response.json();
    if (data.success) {
      // Actualizar la lista de contactos
      await loadContacts();
      
      // Ocultar resultados de búsqueda
      document.getElementById('search-results').classList.add('hidden');
      
      // Limpiar el campo de búsqueda
      document.getElementById('search-input').value = '';
      
      // Mostrar notificación
      alert('Contacto añadido correctamente');
    }
  } catch (error) {
    console.error('Error adding friend:', error);
    alert('Error al añadir contacto: ' + (error.message || 'Error desconocido'));
  }
}

// Eliminar un contacto existente
async function removeFriend(userId) {
  if (!confirm('¿Estás seguro de eliminar este contacto?')) return;
  
  try {
    const response = await fetch(`/api/friends/${userId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Error al eliminar contacto');
    }
    
    const data = await response.json();
    
    // Recargar la lista de contactos
    await loadContacts();
    
    // Si el contacto eliminado era el chat actual, cerrar el chat
    if (currentChat === userId && currentChatType === 'private') {
      currentChat = null;
      currentChatType = null;
      document.getElementById('messages-container').innerHTML = '<div class="no-messages">Selecciona un chat</div>';
      document.getElementById('chat-title').textContent = 'Selecciona un chat';
      document.getElementById('message-input').disabled = true;
      document.getElementById('send-message-btn').disabled = true;
    }
    
    // Mostrar notificación
    alert(data.message || 'Contacto eliminado correctamente');
  } catch (error) {
    console.error('Error removing friend:', error);
    alert('Error al eliminar contacto: ' + (error.message || 'Error desconocido'));
  }
}

// Función auxiliar para mostrar notificaciones (añadir al código)
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Modifica la función initApp para incluir la configuración del buscador
function initApp(user) {
  document.getElementById('auth-section').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
  document.getElementById('welcome-message').textContent = `Bienvenido, ${user.username}`;
  
  currentUserId = user.id;
  initWebSocket(user.id);
  loadContacts();
  loadUserGroups();
  setupUserSearch(); // <-- Añade esta línea para inicializar el buscador
}