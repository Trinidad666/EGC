const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  channel_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Channel',
    required: function() { return !this.private_chat_id; }
  },
  private_chat_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateChat',
    required: function() { return !this.channel_id; }
  },
  content: {
    type: String,
    required: true,
    trim: true,
    maxlength: 2000
  },
  message_type: {
    type: String,
    enum: ['text', 'image', 'video', 'file'],
    default: 'text'
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  isEncrypted: {
    type: Boolean,
    default: false
  }
}, {
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Índices para mejor rendimiento
MessageSchema.index({ channel_id: 1, timestamp: 1 });
MessageSchema.index({ private_chat_id: 1, timestamp: 1 });

module.exports = mongoose.model('Message', MessageSchema);