const mongoose = require('mongoose');

const ChannelSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 50
  },
  description: {
    type: String,
    trim: true,
    maxlength: 200
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  type: {
    type: String,
    enum: ['public', 'private'],
    default: 'public'
  },
  is_active: {
    type: Boolean,
    default: true
  },
  created_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  members: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  admins: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  max_members: {
    type: Number,
    default: 100,
    min: 2
  },
  tags: [{
    type: String,
    trim: true
  }]
}, {
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Índice para búsqueda rápida
ChannelSchema.index({ name: 'text', description: 'text', tags: 'text' });

// Middleware para agregar el creador como admin y miembro
ChannelSchema.pre('save', function(next) {
  if (this.isNew) {
    this.members.push(this.created_by);
    this.admins.push(this.created_by);
  }
  next();
});

// Método para verificar si un usuario es miembro
ChannelSchema.methods.isMember = function(userId) {
  return this.members.some(member => member.equals(userId));
};

// Método para verificar si un usuario es admin
ChannelSchema.methods.isAdmin = function(userId) {
  return this.admins.some(admin => admin.equals(userId));
};

module.exports = mongoose.model('Channel', ChannelSchema);