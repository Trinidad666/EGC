const mongoose = require('mongoose');

const FileSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  channel_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Channel'
  },
  private_chat_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PrivateChat'
  },
  file_url: {
    type: String,
    required: true
  },
  file_type: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('File', FileSchema);