const mongoose = require('mongoose');

const PrivateChatSchema = new mongoose.Schema({
  user1_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  user2_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  messages: [{
    sender_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    content: {
      type: String,
      required: true
    },
    timestamp: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  // Asegurar que no se creen documentos con valores nulos
  strict: 'throw'
});

// Índice compuesto con validación adicional
PrivateChatSchema.index(
  { user1_id: 1, user2_id: 1 }, 
  { 
    unique: true,
    partialFilterExpression: {
      user1_id: { $exists: true, $ne: null },
      user2_id: { $exists: true, $ne: null }
    }
  }
);

// Middleware para validar antes de guardar
PrivateChatSchema.pre('save', function(next) {
  if (!this.user1_id || !this.user2_id) {
    throw new Error('Both user1_id and user2_id are required');
  }
  next();
});

module.exports = mongoose.model('PrivateChat', PrivateChatSchema);