const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect('mongodb+srv://EGC:password1234@cluster0.kbtve.mongodb.net/messaging-platform', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ MongoDB Connected');
  } catch (err) {
    console.error('🔴 MongoDB Connection Error:', err);
    process.exit(1);
  }
};

module.exports = connectDB;