require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const User = require('./models/User');
const Message = require('./models/Message');
const Channel = require('./models/Channel');
const PrivateChat = require('./models/PrivateChat');

// Configuración de Express
const app = express();
const server = http.createServer(app);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Conexión a MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://EGC:password1234@cluster0.kbtve.mongodb.net/messaging-platform', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ MongoDB Connected');
  } catch (err) {
    console.error('🔴 MongoDB Connection Error:', err);
    process.exit(1);
  }
};

// WebSocket Server
const wss = new WebSocket.Server({ server });
const activeUsers = new Map(); // userId -> WebSocket
const userGroups = new Map(); // userId -> Set of groupIds

// Funciones de utilidad
function emitToUser(userId, event, data) {
  if (activeUsers.has(userId)) {
    activeUsers.get(userId).send(JSON.stringify({ type: event, ...data }));
  }
}

async function broadcastToGroup(channelId, event, data, excludeUserId = null) {
  try {
    const channel = await Channel.findById(channelId);
    if (!channel) return;

    channel.members.forEach(memberId => {
      if (excludeUserId && memberId.equals(excludeUserId)) return;
      emitToUser(memberId, event, data);
    });
  } catch (err) {
    console.error('Error broadcasting to group:', err);
  }
}

// Configuración de WebSocket
wss.on('connection', (ws) => {
  console.log('🔌 New WebSocket connection');

  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'register':
          activeUsers.set(data.userId, ws);
          console.log(`📌 Usuario registrado: ${data.userId}`);
          await User.findByIdAndUpdate(data.userId, { status: 'online' });
          
          // Unir a usuario a sus grupos
          const userChannels = await Channel.find({ members: data.userId });
          userGroups.set(data.userId, new Set(userChannels.map(c => c._id.toString())));
          
          // Notificar a contactos
          const user = await User.findById(data.userId).populate('friends');
          user.friends.forEach(friend => {
            emitToUser(friend._id, 'user-status', { userId: data.userId, status: 'online' });
          });
          break;

        case 'join-group':
          if (data.channelId && data.userId) {
            const groupSet = userGroups.get(data.userId) || new Set();
            groupSet.add(data.channelId);
            userGroups.set(data.userId, groupSet);
          }
          break;

        case 'leave-group':
          if (data.channelId && data.userId) {
            const groupSet = userGroups.get(data.userId);
            if (groupSet) {
              groupSet.delete(data.channelId);
            }
          }
          break;

        case 'message':
          if (data.chatType === 'private' && data.senderId && data.recipientId) {
            try {
              const chat = await PrivateChat.findOneAndUpdate(
                {
                  $or: [
                    { user1_id: data.senderId, user2_id: data.recipientId },
                    { user1_id: data.recipientId, user2_id: data.senderId }
                  ]
                },
                {
                  $push: {
                    messages: {
                      sender_id: data.senderId,
                      content: data.content,
                      timestamp: new Date(data.timestamp)
                    }
                  },
                  $setOnInsert: {
                    user1_id: data.senderId < data.recipientId ? data.senderId : data.recipientId,
                    user2_id: data.senderId < data.recipientId ? data.recipientId : data.senderId
                  }
                },
                { 
                  new: true, 
                  upsert: true,
                  sort: { user1_id: 1, user2_id: 1 }
                }
              ).populate('messages.sender_id', 'username _id');
              
              const sender = await User.findById(data.senderId).select('username');
              
              // Enviar al remitente y destinatario
              [data.senderId, data.recipientId].forEach(userId => {
                if (activeUsers.has(userId)) {
                  activeUsers.get(userId).send(JSON.stringify({
                    type: 'message',
                    senderId: data.senderId,
                    senderUsername: sender.username,
                    content: data.content,
                    timestamp: data.timestamp,
                    chatType: 'private',
                    isOwnMessage: userId === data.senderId
                  }));
                }
              });
            } catch (err) {
              console.error('Error processing private message:', err);
            }
          }
          break;

        case 'group-message':
          if (data.channelId && data.senderId) {
            try {
              const channel = await Channel.findById(data.channelId);
              if (!channel || !channel.members.some(member => member.equals(data.senderId))) {
                throw new Error('User is not a member of this channel');
              }

              const message = new Message({
                user_id: data.senderId,
                channel_id: data.channelId,
                content: data.content,
                message_type: 'text'
              });
              
              await message.save();
              const populatedMsg = await Message.findById(message._id).populate('user_id', 'username');
              
              const messageData = {
                type: 'group-message',
                _id: message._id,
                channelId: data.channelId,
                senderId: populatedMsg.user_id._id,
                senderUsername: populatedMsg.user_id.username,
                content: populatedMsg.content,
                timestamp: populatedMsg.timestamp
              };

              // Enviar a todos los miembros del grupo
              channel.members.forEach(memberId => {
                if (activeUsers.has(memberId.toString())) {
                  activeUsers.get(memberId.toString()).send(JSON.stringify({
                    ...messageData,
                    isOwnMessage: memberId.toString() === data.senderId
                  }));
                }
              });
            } catch (err) {
              console.error('Error processing group message:', err);
              emitToUser(data.senderId, 'error', {
                message: 'Error al enviar mensaje al grupo',
                originalType: 'group-message'
              });
            }
          }
          break;

        case 'call-offer':
          if (data.targetId && activeUsers.has(data.targetId)) {
            activeUsers.get(data.targetId).send(JSON.stringify({
              type: 'call-offer',
              senderId: data.senderId,
              offer: data.offer
            }));
          }
          break;

        case 'call-answer':
          if (data.targetId && activeUsers.has(data.targetId)) {
            activeUsers.get(data.targetId).send(JSON.stringify({
              type: 'call-answer',
              answer: data.answer
            }));
          }
          break;

        case 'ice-candidate':
          if (data.targetId && activeUsers.has(data.targetId)) {
            activeUsers.get(data.targetId).send(JSON.stringify({
              type: 'ice-candidate',
              candidate: data.candidate
            }));
          }
          break;

        case 'call-reject':
          if (data.targetId && activeUsers.has(data.targetId)) {
            activeUsers.get(data.targetId).send(JSON.stringify({
              type: 'call-reject',
              from: data.senderId
            }));
          }
          break;

        default:
          console.log('🔴 Tipo de mensaje desconocido:', data.type);
      }
    } catch (err) {
      console.error('Error processing message:', err);
    }
  });

  ws.on('close', async () => {
    for (const [userId, socket] of activeUsers.entries()) {
      if (socket === ws) {
        activeUsers.delete(userId);
        userGroups.delete(userId);
        console.log(`❌ Usuario desconectado: ${userId}`);
        
        await User.findByIdAndUpdate(userId, { status: 'offline' });
        
        // Notificar a contactos
        const user = await User.findById(userId).populate('friends');
        user.friends.forEach(friend => {
          emitToUser(friend._id, 'user-status', { userId, status: 'offline' });
        });
        
        break;
      }
    }
  });
});

// Rutas API
app.use('/auth', require('./routes/auth'));
app.use('/api', require('./routes/api'));

// Ruta para servir la aplicación
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

// Iniciar servidor
connectDB().then(() => {
  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`✅ Server running on http://localhost:${PORT}`);
    console.log(`✅ WebSocket server running on ws://localhost:${PORT}`);
  });
});

// Manejo de errores
process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
  server.close(() => process.exit(1));
});