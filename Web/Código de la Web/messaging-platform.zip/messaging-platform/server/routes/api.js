const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');
const Message = require('../models/Message');
const Channel = require('../models/Channel');
const PrivateChat = require('../models/PrivateChat');
const router = express.Router();

// Obtener perfil del usuario
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password_hash');
    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Obtener contactos del usuario
router.get('/contacts', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).populate('friends', 'username status');
    res.json(user.friends);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Buscar usuarios
router.get('/users/search', auth, async (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query || query.length < 2) {
      return res.status(400).json({ message: 'La búsqueda debe tener al menos 2 caracteres' });
    }
    
    const currentUser = await User.findById(req.user.id);
    
    // Buscar usuarios que no sean el actual, no estén bloqueados y coincidan con la consulta
    const users = await User.find({
      $and: [
        { 
          $or: [
            { username: { $regex: query, $options: 'i' } },
            { email: { $regex: query, $options: 'i' } }
          ]
        },
        { _id: { $ne: req.user.id } }, // Excluir al usuario actual
        { _id: { $nin: currentUser.blocked_users } }, // Excluir usuarios bloqueados
        { blocked_users: { $nin: [req.user.id] } } // Excluir usuarios que te han bloqueado
      ]
    })
    .select('_id username email status') // Solo devolver estos campos
    .limit(10); // Limitar resultados
    
    res.json(users);
  } catch (err) {
    console.error('Error en búsqueda de usuarios:', err);
    res.status(500).json({ message: 'Error en el servidor al buscar usuarios' });
  }
});

// Añadir amigo
router.post('/friends/:userId', auth, async (req, res) => {
  try {
    const { userId } = req.params;
    
    const userToAdd = await User.findById(userId);
    if (!userToAdd) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }
    
    if (userId === req.user.id.toString()) {
      return res.status(400).json({ message: 'No puedes añadirte a ti mismo' });
    }
    
    const user = await User.findById(req.user.id);
    if (user.friends.includes(userId)) {
      return res.status(400).json({ message: 'Este usuario ya es tu amigo' });
    }
    
    if (user.blocked_users.includes(userId)) {
      return res.status(400).json({ message: 'No puedes añadir un usuario bloqueado' });
    }
    
    user.friends.push(userId);
    await user.save();
    
    res.json({ 
      success: true,
      message: 'Amigo añadido correctamente',
      friend: {
        _id: userToAdd._id,
        username: userToAdd.username,
        status: userToAdd.status
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Eliminar amigo
router.delete('/friends/:userId', auth, async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findById(req.user.id);
    user.friends = user.friends.filter(friendId => friendId.toString() !== userId);
    await user.save();
    
    res.json({ message: 'Amigo eliminado correctamente' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Obtener chat privado
router.get('/private-chat/:userId', auth, async (req, res) => {
  try {
    const { userId } = req.params;
    const currentUserId = req.user.id;

    let chat = await PrivateChat.findOne({
      $or: [
        { user1_id: currentUserId, user2_id: userId },
        { user1_id: userId, user2_id: currentUserId }
      ]
    }).populate('messages.sender_id', 'username _id');

    if (!chat) {
      return res.json([]);
    }

    const formattedMessages = chat.messages.map(message => ({
      _id: message._id,
      senderId: message.sender_id._id.toString(),
      senderUsername: message.sender_id.username,
      content: message.content,
      timestamp: message.timestamp,
      isCurrentUser: message.sender_id._id.toString() === currentUserId
    }));

    res.json(formattedMessages);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Enviar mensaje a chat privado
router.post('/private-chat/:userId', auth, async (req, res) => {
  try {
    const { userId } = req.params;
    const { content } = req.body;
    const currentUserId = req.user.id;

    // Validar IDs
    if (!currentUserId || !userId) {
      return res.status(400).json({ message: 'User IDs are required' });
    }

    // Determinar el orden consistente de los IDs
    const user1Id = currentUserId < userId ? currentUserId : userId;
    const user2Id = currentUserId < userId ? userId : currentUserId;

    let chat = await PrivateChat.findOneAndUpdate(
      {
        $or: [
          { user1_id: user1Id, user2_id: user2Id },
          { user1_id: user2Id, user2_id: user1Id }
        ]
      },
      {
        $push: {
          messages: {
            sender_id: currentUserId,
            content: content,
            timestamp: new Date()
          }
        },
        $setOnInsert: {
          user1_id: user1Id,
          user2_id: user2Id
        }
      },
      { 
        new: true, 
        upsert: true,
        sort: { user1_id: 1, user2_id: 1 }
      }
    ).populate('messages.sender_id', 'username _id');

    const lastMessage = chat.messages[chat.messages.length - 1];
    
    const responseMessage = {
      _id: lastMessage._id,
      senderId: lastMessage.sender_id._id.toString(),
      senderUsername: lastMessage.sender_id.username,
      content: lastMessage.content,
      timestamp: lastMessage.timestamp,
      isCurrentUser: false
    };

    res.json(responseMessage);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Crear un nuevo grupo
router.post('/channels', auth, async (req, res) => {
  try {
    const { name, description, type, tags } = req.body;
    
    const channel = new Channel({
      name,
      description,
      type,
      tags,
      created_by: req.user.id
    });

    await channel.save();
    
    // Populate para devolver datos completos
    const populatedChannel = await Channel.findById(channel._id)
      .populate('created_by', 'username')
      .populate('members', 'username status');

    res.status(201).json(populatedChannel);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al crear el grupo' });
  }
});

// Buscar grupos públicos
router.get('/channels/search', auth, async (req, res) => {
  try {
    const { query } = req.query;
    
    const channels = await Channel.find({
      type: 'public',
      $text: { $search: query }
    })
    .populate('created_by', 'username')
    .populate('members', 'username status')
    .limit(20);

    res.json(channels);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error en la búsqueda' });
  }
});

// Unirse a un grupo
router.post('/channels/:id/join', auth, async (req, res) => {
  try {
    const channel = await Channel.findById(req.params.id);
    
    if (!channel) {
      return res.status(404).json({ message: 'Grupo no encontrado' });
    }

    if (channel.members.includes(req.user.id)) {
      return res.status(400).json({ message: 'Ya eres miembro de este grupo' });
    }

    if (channel.members.length >= channel.max_members) {
      return res.status(400).json({ message: 'El grupo está lleno' });
    }

    channel.members.push(req.user.id);
    await channel.save();

    res.json({ 
      success: true,
      message: 'Te has unido al grupo exitosamente'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al unirse al grupo' });
  }
});

// Salir de un grupo
router.post('/channels/:id/leave', auth, async (req, res) => {
  try {
    const channel = await Channel.findById(req.params.id);
    
    if (!channel) {
      return res.status(404).json({ message: 'Grupo no encontrado' });
    }

    if (!channel.members.includes(req.user.id)) {
      return res.status(400).json({ message: 'No eres miembro de este grupo' });
    }

    // Si es el creador, no puede salir (debe transferir propiedad o eliminar el grupo)
    if (channel.created_by.equals(req.user.id)) {
      return res.status(400).json({ 
        message: 'Eres el creador del grupo. Transfiere la propiedad o elimina el grupo.' 
      });
    }

    channel.members = channel.members.filter(member => !member.equals(req.user.id));
    channel.admins = channel.admins.filter(admin => !admin.equals(req.user.id));
    await channel.save();

    res.json({ 
      success: true,
      message: 'Has salido del grupo exitosamente'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al salir del grupo' });
  }
});

// Eliminar un grupo (solo para admins/creador)
router.delete('/channels/:id', auth, async (req, res) => {
  try {
    const channel = await Channel.findById(req.params.id);
    
    if (!channel) {
      return res.status(404).json({ message: 'Grupo no encontrado' });
    }

    // Solo el creador puede eliminar el grupo
    if (!channel.created_by.equals(req.user.id)) {
      return res.status(403).json({ message: 'No tienes permiso para eliminar este grupo' });
    }

    await Channel.deleteOne({ _id: req.params.id });
    
    // Opcional: Eliminar todos los mensajes asociados
    await Message.deleteMany({ channel_id: req.params.id });

    res.json({ 
      success: true,
      message: 'Grupo eliminado exitosamente'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al eliminar el grupo' });
  }
});

// Obtener grupos del usuario
router.get('/user/channels', auth, async (req, res) => {
  try {
    const channels = await Channel.find({ members: req.user.id })
      .populate('created_by', 'username')
      .populate('members', 'username status');

    res.json(channels);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al obtener grupos' });
  }
});

// Obtener mensajes de un grupo
router.get('/channels/:id/messages', auth, async (req, res) => {
  try {
    const channel = await Channel.findById(req.params.id);
    
    if (!channel) {
      return res.status(404).json({ message: 'Grupo no encontrado' });
    }

    // Verificar que el usuario es miembro del grupo
    if (!channel.members.some(member => member.equals(req.user.id))) {
      return res.status(403).json({ message: 'No eres miembro de este grupo' });
    }

    const messages = await Message.find({ channel_id: req.params.id })
      .sort({ timestamp: 1 })
      .populate('user_id', 'username');
    
    const formattedMessages = messages.map(message => ({
      _id: message._id,
      senderId: message.user_id._id.toString(),
      senderUsername: message.user_id.username,
      content: message.content,
      timestamp: message.timestamp,
      isCurrentUser: message.user_id._id.toString() === req.user.id
    }));

    res.json(formattedMessages);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al obtener mensajes del grupo' });
  }
});

// Enviar mensaje a grupo
router.post('/channels/:id/messages', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const channel = await Channel.findById(req.params.id);
    
    if (!channel) {
      return res.status(404).json({ message: 'Grupo no encontrado' });
    }

    // Verificar membresía
    if (!channel.members.some(member => member.equals(req.user.id))) {
      return res.status(403).json({ message: 'No eres miembro de este grupo' });
    }

    // Crear y guardar mensaje
    const message = new Message({
      user_id: req.user.id,
      channel_id: req.params.id,
      content,
      message_type: 'text'
    });

    await message.save();
    
    // Populate para obtener datos del usuario
    const populatedMessage = await Message.findById(message._id)
      .populate('user_id', 'username');
    
    res.status(201).json({
      _id: populatedMessage._id,
      senderId: populatedMessage.user_id._id.toString(),
      senderUsername: populatedMessage.user_id.username,
      content: populatedMessage.content,
      timestamp: populatedMessage.timestamp,
      isCurrentUser: true
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error al enviar mensaje' });
  }
});


module.exports = router;