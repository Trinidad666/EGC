let socket;
let currentChat = null;
let currentChatType = null; // 'private' o 'group'
let currentUserId = null;

// Inicializar WebSocket
function initWebSocket(userId) {
  currentUserId = userId;
  socket = new WebSocket(`ws://${window.location.hostname}:${window.location.port}`);

  socket.onopen = () => {
    console.log('WebSocket connected');
    socket.send(JSON.stringify({ 
      type: 'register', 
      userId: currentUserId 
    }));
    
    // Recargar grupos al reconectar
    loadUserGroups();
  };

  socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    console.log('WebSocket message:', data.type);
    
    switch (data.type) {
      case 'message':
        if (data.chatType === 'private' && 
            ((data.senderId === currentChat && currentChatType === 'private') || 
             (data.recipientId === currentChat && currentChatType === 'private'))) {
          displayMessage({
            senderId: data.senderId,
            senderUsername: data.senderUsername,
            content: data.content,
            timestamp: data.timestamp,
            isCurrentUser: data.senderId === currentUserId
          });
          scrollToBottom();
        }
        break;
        
      case 'group-message':
        if (data.channelId === currentChat && currentChatType === 'group') {
          displayMessage({
            _id: data._id,
            senderId: data.senderId,
            senderUsername: data.senderUsername,
            content: data.content,
            timestamp: data.timestamp,
            isCurrentUser: data.isOwnMessage
          });
          scrollToBottom();
        }
        break;
        
      case 'user-status':
        updateUserStatus(data.userId, data.status);
        break;
        
      case 'call-offer':
        handleIncomingCall(data);
        break;
        
      case 'error':
        if (data.originalType === 'group-message') {
          alert(`Error: ${data.message}`);
        }
        break;
    }
  };

  socket.onclose = () => {
    console.log('WebSocket disconnected. Reconnecting...');
    setTimeout(() => initWebSocket(userId), 5000);
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
}

// Abrir chat privado
async function openPrivateChat(userId, username) {
  currentChat = userId;
  currentChatType = 'private';
  document.getElementById('chat-title').textContent = username;
  document.getElementById('start-call-btn').disabled = false;
  
  try {
    const response = await fetch(`/api/private-chat/${userId}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading chat');
    
    const messages = await response.json();
    displayMessages(messages);
    setupMessageInput();
  } catch (error) {
    console.error('Error loading private chat:', error);
    alert('Error al cargar el chat');
  }
}

// Buscar usuarios
document.getElementById('search-input').addEventListener('input', async (e) => {
  const query = e.target.value.trim();
  const searchResults = document.getElementById('search-results');
  
  if (query.length < 2) {
    searchResults.classList.add('hidden');
    return;
  }

  try {
    const response = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error en la búsqueda');
    
    const users = await response.json();
    displaySearchResults(users);
  } catch (error) {
    console.error('Error searching users:', error);
    searchResults.innerHTML = '<div class="search-result-item error">Error al buscar usuarios</div>';
    searchResults.classList.remove('hidden');
  }
});

// Mostrar resultados de búsqueda
function displaySearchResults(users) {
  const searchResults = document.getElementById('search-results');
  searchResults.innerHTML = '';
  
  if (users.length === 0) {
    searchResults.innerHTML = '<div class="search-result-item">No se encontraron usuarios</div>';
  } else {
    users.forEach(user => {
      const userElement = document.createElement('div');
      userElement.className = 'search-result-item';
      userElement.innerHTML = `
        <div class="user-info">
          <div class="username">${user.username}</div>
          <div class="user-status ${user.status === 'online' ? 'online' : 'offline'}">${user.status}</div>
        </div>
        <button class="add-friend-btn" data-userid="${user._id}">
          ${isFriend(user._id) ? 'Amigo' : 'Agregar'}
        </button>
      `;
      
      const addBtn = userElement.querySelector('.add-friend-btn');
      if (!addBtn.disabled) {
        addBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          await addFriend(user._id);
        });
      }
      
      searchResults.appendChild(userElement);
    });
  }
  
  searchResults.classList.remove('hidden');
}

// Verificar si ya es amigo
function isFriend(userId) {
  const user = JSON.parse(localStorage.getItem('user'));
  return user.friends && user.friends.some(friend => friend._id === userId);
}

// Añadir amigo
async function addFriend(userId) {
  try {
    const response = await fetch(`/api/friends/${userId}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // Actualizar el usuario en localStorage
      const user = JSON.parse(localStorage.getItem('user'));
      if (!user.friends) user.friends = [];
      user.friends.push({ _id: userId });
      localStorage.setItem('user', JSON.stringify(user));
      
      // Cerrar los resultados de búsqueda y limpiar el input
      document.getElementById('search-results').classList.add('hidden');
      document.getElementById('search-input').value = '';
      
      // Mostrar mensaje de éxito
      alert('Usuario agregado como amigo exitosamente');
      
      // Recargar la lista de contactos
      loadContacts();
    } else {
      alert(data.message || 'Error al agregar amigo');
    }
  } catch (error) {
    console.error('Error adding friend:', error);
    alert('Error al conectar con el servidor');
  }
}

// Abrir chat de grupo
async function openGroupChat(groupId, groupName) {
  currentChat = groupId;
  currentChatType = 'group';
  document.getElementById('chat-title').textContent = groupName;
  document.getElementById('start-call-btn').disabled = true;
  
  try {
    // Unirse al grupo en WebSocket
    socket.send(JSON.stringify({
      type: 'join-group',
      channelId: groupId,
      userId: currentUserId
    }));
    
    // Cargar mensajes existentes
    const response = await fetch(`/api/channels/${groupId}/messages`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading messages');
    
    const messages = await response.json();
    displayMessages(messages);
    setupMessageInput();
  } catch (error) {
    console.error('Error loading group chat:', error);
    alert('Error al cargar el grupo');
  }
}

// Configurar input de mensajes
function setupMessageInput() {
  const messageInput = document.getElementById('message-input');
  const sendMessageBtn = document.getElementById('send-message-btn');
  
  messageInput.disabled = false;
  sendMessageBtn.disabled = false;

  const sendMessage = async () => {
    const content = messageInput.value.trim();
    if (!content || !currentChat) return;

    try {
      const timestamp = new Date().toISOString();
      
      if (currentChatType === 'private') {
        socket.send(JSON.stringify({
          type: 'message',
          senderId: currentUserId,
          recipientId: currentChat,
          content: content,
          chatType: 'private',
          timestamp: timestamp
        }));
        
        // Mostrar mensaje localmente inmediatamente
        displayMessage({
          senderId: currentUserId,
          senderUsername: JSON.parse(localStorage.getItem('user')).username,
          content: content,
          timestamp: timestamp,
          isCurrentUser: true
        });
        scrollToBottom();
        
      } else if (currentChatType === 'group') {
        socket.send(JSON.stringify({
          type: 'group-message',
          senderId: currentUserId,
          channelId: currentChat,
          content: content
        }));
        
        // Mostrar mensaje localmente inmediatamente (optimista)
        displayMessage({
          senderId: currentUserId,
          senderUsername: JSON.parse(localStorage.getItem('user')).username,
          content: content,
          timestamp: new Date().toISOString(),
          isCurrentUser: true
        });
        scrollToBottom();
      }
      
      messageInput.value = '';
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Error al enviar el mensaje');
    }
  };

  messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
  });

  sendMessageBtn.addEventListener('click', sendMessage);
}

// Mostrar mensajes
function displayMessages(messages) {
  const messagesContainer = document.getElementById('messages-container');
  messagesContainer.innerHTML = '';
  
  if (messages.length === 0) {
    messagesContainer.innerHTML = '<div class="no-messages">No hay mensajes aún</div>';
    return;
  }
  
  messages.forEach(message => {
    displayMessage(message);
  });
  
  scrollToBottom();
}

// Mostrar un mensaje individual
function displayMessage(message) {
  const messagesContainer = document.getElementById('messages-container');
  const isCurrentUser = message.isCurrentUser;
  
  const messageElement = document.createElement('div');
  messageElement.className = `message ${isCurrentUser ? 'my-message' : 'contact-message'}`;
  
  const messageTime = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
  
  messageElement.innerHTML = `
    <div class="message-sender">${isCurrentUser ? 'Tú' : message.senderUsername}</div>
    <div class="message-content">${message.content}</div>
    <div class="message-time">${messageTime}</div>
  `;
  
  messagesContainer.appendChild(messageElement);
}

// Función para desplazarse al final del chat
function scrollToBottom() {
  const messagesContainer = document.getElementById('messages-container');
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Actualizar estado de usuario
function updateUserStatus(userId, status) {
  const contacts = document.querySelectorAll('.contact-item');
  contacts.forEach(contact => {
    if (contact.dataset.userid === userId) {
      const statusIndicator = contact.querySelector('.contact-status');
      statusIndicator.className = `contact-status ${status === 'online' ? 'status-online' : 'status-offline'}`;
    }
  });
}

// Inicializar llamada
document.getElementById('start-call-btn').addEventListener('click', () => {
  if (currentChatType === 'private' && currentChat) {
    startCall(currentChat);
  }
});

// Finalizar llamada
document.getElementById('end-call-btn').addEventListener('click', endCall);

// Cargar contactos
async function loadContacts() {
  try {
    const response = await fetch('/api/contacts', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading contacts');
    
    const contacts = await response.json();
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = '';
    
    if (contacts.length === 0) {
      contactsList.innerHTML = '<div class="no-contacts">No tienes contactos aún</div>';
      return;
    }
    
    contacts.forEach(contact => {
      const contactItem = document.createElement('div');
      contactItem.className = 'contact-item';
      contactItem.dataset.userid = contact._id;
      contactItem.innerHTML = `
        <div class="contact-status ${contact.status === 'online' ? 'status-online' : 'status-offline'}"></div>
        <span>${contact.username}</span>
        <div class="contact-actions">
          <button class="remove-friend-btn" data-userid="${contact._id}">Eliminar</button>
        </div>
      `;
      
      contactItem.addEventListener('click', (e) => {
        if (!e.target.classList.contains('remove-friend-btn')) {
          openPrivateChat(contact._id, contact.username);
        }
      });
      
      const removeBtn = contactItem.querySelector('.remove-friend-btn');
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeFriend(contact._id);
      });
      
      contactsList.appendChild(contactItem);
    });
  } catch (error) {
    console.error('Error loading contacts:', error);
  }
}

// Cargar grupos del usuario
async function loadUserGroups() {
  try {
    const response = await fetch('/api/user/channels', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    if (!response.ok) throw new Error('Error loading groups');
    
    const groups = await response.json();
    const groupsList = document.getElementById('groups-list');
    groupsList.innerHTML = '';
    
    if (groups.length === 0) {
      groupsList.innerHTML = '<div class="no-groups">No estás en ningún grupo</div>';
      return;
    }
    
    groups.forEach(group => {
      const groupElement = document.createElement('div');
      groupElement.className = 'group-item';
      groupElement.dataset.groupid = group._id;
      groupElement.innerHTML = `
        <div class="group-info">
          <div class="group-name">${group.name}</div>
          <div class="group-description">${group.description || 'Sin descripción'}</div>
          <div class="group-members">${group.members.length} miembros</div>
        </div>
        <div class="group-actions">
          <button class="leave-group-btn" data-groupid="${group._id}">Salir</button>
          ${group.created_by._id === JSON.parse(localStorage.getItem('user')).id ? 
            `<button class="delete-group-btn" data-groupid="${group._id}">Eliminar</button>` : ''}
        </div>
      `;
      
      groupElement.addEventListener('click', () => {
        openGroupChat(group._id, group.name);
      });
      
      const leaveBtn = groupElement.querySelector('.leave-group-btn');
      leaveBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await leaveGroup(group._id);
      });
      
      const deleteBtn = groupElement.querySelector('.delete-group-btn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (confirm('¿Estás seguro de eliminar este grupo?')) {
            await deleteGroup(group._id);
          }
        });
      }
      
      groupsList.appendChild(groupElement);
    });
  } catch (error) {
    console.error('Error loading user groups:', error);
  }
}

// Funciones para manejar grupos
async function leaveGroup(groupId) {
  try {
    const response = await fetch(`/api/channels/${groupId}/leave`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      alert(data.message);
      loadUserGroups();
      
      // Salir del grupo en WebSocket
      socket.send(JSON.stringify({
        type: 'leave-group',
        channelId: groupId,
        userId: currentUserId
      }));
      
      // Si estábamos en ese grupo, cerrar el chat
      if (currentChat === groupId) {
        currentChat = null;
        currentChatType = null;
        document.getElementById('messages-container').innerHTML = '<div>Selecciona un chat</div>';
        document.getElementById('chat-title').textContent = 'Selecciona un chat';
        document.getElementById('message-input').disabled = true;
        document.getElementById('send-message-btn').disabled = true;
      }
    } else {
      alert(data.message || 'Error al salir del grupo');
    }
  } catch (error) {
    console.error('Error leaving group:', error);
    alert('Error al conectar con el servidor');
  }
}

async function deleteGroup(groupId) {
  try {
    const response = await fetch(`/api/channels/${groupId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
    
    const data = await response.json();
    
    if (response.ok) {
      alert(data.message);
      loadUserGroups();
      
      // Si estábamos en ese grupo, cerrar el chat
      if (currentChat === groupId) {
        currentChat = null;
        currentChatType = null;
        document.getElementById('messages-container').innerHTML = '<div>Selecciona un chat</div>';
        document.getElementById('chat-title').textContent = 'Selecciona un chat';
        document.getElementById('message-input').disabled = true;
        document.getElementById('send-message-btn').disabled = true;
      }
    } else {
      alert(data.message || 'Error al eliminar el grupo');
    }
  } catch (error) {
    console.error('Error deleting group:', error);
    alert('Error al conectar con el servidor');
  }
}

// Inicializar la aplicación
function initApp(user) {
  document.getElementById('auth-section').classList.add('hidden');
  document.getElementById('main-app').classList.remove('hidden');
  document.getElementById('welcome-message').textContent = `Bienvenido, ${user.username}`;
  
  currentUserId = user.id;
  initWebSocket(user.id);
  loadContacts();
  loadUserGroups();
}