let peerConnection;
let localStream;
let currentCall = null;

// Configuración mejorada de ICE Servers
const configuration = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun2.l.google.com:19302" },
    // Si tienes un servidor TURN, añádelo aquí
    // {
    //   urls: "turn:your-turn-server.com",
    //   username: "username",
    //   credential: "password"
    // }
  ],
  iceTransportPolicy: "all"
};

// Iniciar llamada
async function startCall(targetUserId) {
  try {
    currentCall = targetUserId;
    
    // Obtener stream local
    localStream = await navigator.mediaDevices.getUserMedia({ 
      audio: true,
      video: false // Cambia a true si quieres video
    });
    
    // Crear conexión RTCPeerConnection
    peerConnection = new RTCPeerConnection(configuration);
    
    // Añadir stream local
    localStream.getTracks().forEach(track => {
      peerConnection.addTrack(track, localStream);
    });
    
    // Manejar candidatos ICE
    peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        socket.send(JSON.stringify({
          type: "ice-candidate",
          targetId: targetUserId,
          candidate: event.candidate
        }));
      }
    };
    
    // Manejar stream remoto
    peerConnection.ontrack = (event) => {
      const remoteAudio = document.getElementById("remote-audio");
      if (!remoteAudio.srcObject) {
        remoteAudio.srcObject = event.streams[0];
      }
    };
    
    // Crear oferta
    const offer = await peerConnection.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: false // Cambia a true si usas video
    });
    
    await peerConnection.setLocalDescription(offer);
    
    // Enviar oferta al otro usuario
    socket.send(JSON.stringify({
      type: "call-offer",
      senderId: currentUserId,
      targetId: targetUserId,
      offer: offer
    }));
    
    // Mostrar interfaz de llamada
    showCallInterface(`Llamando a ${targetUserId}...`);
    
  } catch (error) {
    console.error("Error al iniciar llamada:", error);
    endCall();
    alert("Error al iniciar la llamada. Asegúrate de permitir el acceso al micrófono.");
  }
}

// Manejar llamadas entrantes
function handleIncomingCall(data) {
  showCallInterface(`Llamada entrante de ${data.senderId}`, true);
  
  document.getElementById("accept-call-btn").onclick = async () => {
    try {
      // Obtener stream local
      localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Crear conexión RTCPeerConnection
      peerConnection = new RTCPeerConnection(configuration);
      
      // Añadir stream local
      localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
      });
      
      // Manejar candidatos ICE
      peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          socket.send(JSON.stringify({
            type: "ice-candidate",
            targetId: data.senderId,
            candidate: event.candidate
          }));
        }
      };
      
      // Manejar stream remoto
      peerConnection.ontrack = (event) => {
        const remoteAudio = document.getElementById("remote-audio");
        remoteAudio.srcObject = event.streams[0];
        document.getElementById("call-status").textContent = "En llamada...";
      };
      
      // Establecer descripción remota
      await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
      
      // Crear respuesta
      const answer = await peerConnection.createAnswer();
      await peerConnection.setLocalDescription(answer);
      
      // Enviar respuesta al llamante
      socket.send(JSON.stringify({
        type: "call-answer",
        targetId: data.senderId,
        answer: answer
      }));
      
    } catch (error) {
      console.error("Error al aceptar llamada:", error);
      endCall();
    }
  };
  
  document.getElementById("reject-call-btn").onclick = () => {
    socket.send(JSON.stringify({
      type: "call-reject",
      targetId: data.senderId
    }));
    endCall();
  };
}

// Manejar mensajes WebSocket para WebRTC
socket.onmessage = async (event) => {
  const data = JSON.parse(event.data);
  
  switch (data.type) {
    case "call-offer":
      handleIncomingCall(data);
      break;
      
    case "call-answer":
      if (peerConnection) {
        await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
      }
      break;
      
    case "ice-candidate":
      if (peerConnection && data.candidate) {
        try {
          await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        } catch (error) {
          console.error("Error al añadir ICE candidate:", error);
        }
      }
      break;
      
    case "call-reject":
      alert("La llamada fue rechazada");
      endCall();
      break;
  }
};

// Mostrar interfaz de llamada
function showCallInterface(status, showAccept = false) {
  const callModal = document.getElementById("call-modal");
  const callStatus = document.getElementById("call-status");
  const acceptBtn = document.getElementById("accept-call-btn");
  const rejectBtn = document.getElementById("reject-call-btn");
  
  callModal.classList.remove("hidden");
  callStatus.textContent = status;
  
  acceptBtn.style.display = showAccept ? "block" : "none";
  rejectBtn.textContent = showAccept ? "Rechazar" : "Colgar";
}

// Finalizar llamada
function endCall() {
  if (peerConnection) {
    peerConnection.close();
    peerConnection = null;
  }
  
  if (localStream) {
    localStream.getTracks().forEach(track => track.stop());
    localStream = null;
  }
  
  document.getElementById("call-modal").classList.add("hidden");
  const remoteAudio = document.getElementById("remote-audio");
  if (remoteAudio.srcObject) {
    remoteAudio.srcObject = null;
  }
  
  currentCall = null;
}

// Manejar errores de conexión
if (peerConnection) {
  peerConnection.oniceconnectionstatechange = () => {
    if (peerConnection.iceConnectionState === "disconnected" || 
        peerConnection.iceConnectionState === "failed") {
      console.log("Conexión fallida, intentando reiniciar...");
      endCall();
    }
  };
}