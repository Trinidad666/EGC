// public/js/groups.js
document.addEventListener('DOMContentLoaded', () => {
    // Elementos del DOM
    const newGroupBtn = document.getElementById('new-group-btn');
    const groupModal = document.getElementById('group-modal');
    const cancelGroupBtn = document.getElementById('cancel-group-btn');
    const createGroupForm = document.getElementById('create-group-form');
    const searchGroupInput = document.getElementById('search-group-input');
    const searchGroupResults = document.getElementById('search-group-results');
    const groupsList = document.getElementById('groups-list');
  
    // Cargar grupos del usuario al iniciar
    if (localStorage.getItem('token')) {
      loadUserGroups();
    }
  
    // Mostrar modal para crear grupo
    newGroupBtn.addEventListener('click', () => {
      groupModal.classList.remove('hidden');
    });
  
    // Ocultar modal
    cancelGroupBtn.addEventListener('click', () => {
      groupModal.classList.add('hidden');
    });
  
    // Crear nuevo grupo
    createGroupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const name = document.getElementById('group-name').value;
      const description = document.getElementById('group-description').value;
      const type = document.getElementById('group-type').value;
      const tags = document.getElementById('group-tags').value
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);
  
      try {
        const response = await fetch('/api/channels', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({ name, description, type, tags })
        });
  
        const data = await response.json();
  
        if (response.ok) {
          groupModal.classList.add('hidden');
          createGroupForm.reset();
          loadUserGroups();
          alert('Grupo creado exitosamente!');
        } else {
          alert(data.message || 'Error al crear el grupo');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('Error al conectar con el servidor');
      }
    });
  
    // Buscar grupos públicos
    searchGroupInput.addEventListener('input', async (e) => {
      const query = e.target.value.trim();
      if (query.length < 2) {
        searchGroupResults.classList.add('hidden');
        return;
      }
  
      try {
        const response = await fetch(`/api/channels/search?query=${encodeURIComponent(query)}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        const groups = await response.json();
        displaySearchResults(groups);
      } catch (error) {
        console.error('Error searching groups:', error);
      }
    });
  
    // Cargar grupos del usuario
    async function loadUserGroups() {
      try {
        const response = await fetch('/api/user/channels', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        const groups = await response.json();
        displayUserGroups(groups);
      } catch (error) {
        console.error('Error loading user groups:', error);
      }
    }
  
    // Mostrar resultados de búsqueda
    function displaySearchResults(groups) {
      searchGroupResults.innerHTML = '';
      
      if (groups.length === 0) {
        searchGroupResults.innerHTML = '<div class="search-result-item">No se encontraron grupos</div>';
      } else {
        groups.forEach(group => {
          const groupElement = document.createElement('div');
          groupElement.className = 'search-result-item';
          groupElement.innerHTML = `
            <div class="group-info">
              <div class="group-name">${group.name}</div>
              <div class="group-description">${group.description || 'Sin descripción'}</div>
              <div class="group-members">${group.members.length} miembros</div>
            </div>
            <button class="join-group-btn" data-groupid="${group._id}">Unirse</button>
          `;
          
          groupElement.querySelector('.join-group-btn').addEventListener('click', async (e) => {
            e.stopPropagation();
            await joinGroup(group._id);
          });
          
          searchGroupResults.appendChild(groupElement);
        });
      }
      
      searchGroupResults.classList.remove('hidden');
    }
  
    // Mostrar grupos del usuario
    function displayUserGroups(groups) {
      groupsList.innerHTML = '';
      
      if (groups.length === 0) {
        groupsList.innerHTML = '<div class="no-groups">No estás en ningún grupo aún</div>';
        return;
      }
      
      groups.forEach(group => {
        const groupElement = document.createElement('div');
        groupElement.className = 'group-item';
        groupElement.innerHTML = `
          <div class="group-info">
            <div class="group-name">${group.name}</div>
            <div class="group-description">${group.description || 'Sin descripción'}</div>
            <div class="group-members">${group.members.length} miembros</div>
          </div>
          <div class="group-actions">
            <button class="leave-group-btn" data-groupid="${group._id}">Salir</button>
            ${group.created_by._id === JSON.parse(localStorage.getItem('user')).id ? 
              `<button class="delete-group-btn" data-groupid="${group._id}">Eliminar</button>` : ''}
          </div>
        `;
        
        groupElement.addEventListener('click', () => {
          openGroupChat(group._id, group.name);
        });
        
        const leaveBtn = groupElement.querySelector('.leave-group-btn');
        leaveBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          await leaveGroup(group._id);
        });
        
        const deleteBtn = groupElement.querySelector('.delete-group-btn');
        if (deleteBtn) {
          deleteBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm('¿Estás seguro de que quieres eliminar este grupo?')) {
              await deleteGroup(group._id);
            }
          });
        }
        
        groupsList.appendChild(groupElement);
      });
    }
  
    // Unirse a un grupo
    async function joinGroup(groupId) {
      try {
        const response = await fetch(`/api/channels/${groupId}/join`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        const data = await response.json();
        
        if (response.ok) {
          alert(data.message);
          loadUserGroups();
          searchGroupResults.classList.add('hidden');
          searchGroupInput.value = '';
        } else {
          alert(data.message || 'Error al unirse al grupo');
        }
      } catch (error) {
        console.error('Error joining group:', error);
        alert('Error al conectar con el servidor');
      }
    }
  
    // Salir de un grupo
    async function leaveGroup(groupId) {
      try {
        const response = await fetch(`/api/channels/${groupId}/leave`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        const data = await response.json();
        
        if (response.ok) {
          alert(data.message);
          loadUserGroups();
        } else {
          alert(data.message || 'Error al salir del grupo');
        }
      } catch (error) {
        console.error('Error leaving group:', error);
        alert('Error al conectar con el servidor');
      }
    }
  
    // Eliminar un grupo
    async function deleteGroup(groupId) {
      try {
        const response = await fetch(`/api/channels/${groupId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        const data = await response.json();
        
        if (response.ok) {
          alert(data.message);
          loadUserGroups();
        } else {
          alert(data.message || 'Error al eliminar el grupo');
        }
      } catch (error) {
        console.error('Error deleting group:', error);
        alert('Error al conectar con el servidor');
      }
    }
  
    // Abrir chat de grupo
    async function openGroupChat(groupId, groupName) {
      try {
        // Cerrar cualquier chat abierto previamente
        currentChat = null;
        currentChatType = null;
        
        // Establecer el nuevo chat de grupo
        currentChat = groupId;
        currentChatType = 'group';
        
        // Actualizar la UI
        document.getElementById('chat-title').textContent = groupName;
        document.getElementById('start-call-btn').disabled = true;
        document.getElementById('message-input').disabled = false;
        document.getElementById('send-message-btn').disabled = false;
        
        // Unirse al grupo en WebSocket
        if (socket && socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({
            type: 'join-group',
            channelId: groupId,
            userId: currentUserId
          }));
        }
        
        // Cargar mensajes existentes
        const response = await fetch(`/api/channels/${groupId}/messages`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        
        if (!response.ok) throw new Error('Error loading messages');
        
        const messages = await response.json();
        displayMessages(messages);
        setupMessageInput();
        
        // Desplazarse al final del chat
        scrollToBottom();
        
      } catch (error) {
        console.error('Error opening group chat:', error);
        alert('Error al cargar el grupo');
        
        // Resetear el chat si hay error
        currentChat = null;
        currentChatType = null;
        document.getElementById('messages-container').innerHTML = '<div class="no-messages">Error al cargar el grupo</div>';
        document.getElementById('chat-title').textContent = 'Selecciona un chat';
        document.getElementById('message-input').disabled = true;
        document.getElementById('send-message-btn').disabled = true;
      }
    }
  });